import boto3
import tinify
from os import path

tinify.key = 'YOUR_TINIFY_API_KEY'


s3 = boto3.resource('s3')
destination_bucket = 'YOUR_DESTINATION_BUCKET_NAME'

def handler(event, context):
    for key in event.get('Records'):
        object_key = key['s3']['object']['key']
        bucket_source = key['s3']['bucket']['name']
        extension = path.splitext(object_key)[1].lower()

        if extension in ['.jpeg', '.jpg', '.png']:
            obj = s3.Object(bucket_name=bucket_source,key=object_key)
            obj_body = obj.get()['Body'].read()
            result_data = tinify.from_buffer(obj_body).to_buffer()
            obj = s3.Object(bucket_name=destination_bucket,key=object_key)
            obj.put(Body=result_data)

            print('File saved at {}/{}'.format(
            destination_bucket,
            object_key))