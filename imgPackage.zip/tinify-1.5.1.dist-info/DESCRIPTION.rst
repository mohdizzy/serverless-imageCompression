Python client for the Tinify API. Tinify compresses your images intelligently. Read more at https://tinify.com.


